package beanPod;

public class CourseBean {
	
	private String courseID;
	private String subjectID;
	private int courseCredNum;

	public String getCourseID() {
		return courseID;
	}

	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}

	public String getSubjectID() {
		return subjectID;
	}

	public void setSubjectID(String subjectID) {
		this.subjectID = subjectID;
	}

	public int getCourseCredNum() {
		return courseCredNum;
	}

	public void setCourseCredNum(int courseCredNum) {
		this.courseCredNum = courseCredNum;
	}
}
